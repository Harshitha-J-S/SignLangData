# signLangYOLOV5 > 2024-12-26 9:49pm
https://universe.roboflow.com/sign-language-z2ejq/signlangyolov5

Provided by a Roboflow user
License: CC BY 4.0

