# kansign > 2025-01-11 11:24am
https://universe.roboflow.com/sign-language-z2ejq/kansign

Provided by a Roboflow user
License: CC BY 4.0

