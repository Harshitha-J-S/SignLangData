# signLangYOLOV5Kan > 2025-01-10 11:49pm
https://universe.roboflow.com/sign-language-z2ejq/signlangyolov5kan

Provided by a Roboflow user
License: CC BY 4.0

