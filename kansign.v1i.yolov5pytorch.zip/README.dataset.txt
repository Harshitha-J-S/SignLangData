# kansign > 2025-01-11 12:20am
https://universe.roboflow.com/sign-language-z2ejq/kansign

Provided by a Roboflow user
License: CC BY 4.0

